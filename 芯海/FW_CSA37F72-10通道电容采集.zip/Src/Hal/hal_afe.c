/**
* @file                hal_afe.c
* @brief
* @author
* @version             V0.1.0
* @date                2020.7.1
* @details
* @copyright           (C) COPYRIGHT 2020 SHENZHEN CHIPSEA TECHNOLOGIES CO.,LTD.ALL RIGHTS RESERVED
* @note
*/
/** @addtogroup HAL��
  * @{
  */
/**
 * @defgroup AFEģ��
 * @brief AFEģ��
 * @details 
 * @{
 */
/* Includes ------------------------------------------------------------------*/

//standard
#include <stdint.h>
#include <string.h>

//driver
#include "csa37f7x.h"
#include "csa37f7x_rcc.h"

#include "csa37f7x_afe2.h"
#include "csa37f7x_i2c.h"

#include "csa37f7x_syscfg.h"
#include "csa37f7x_misc.h"

//hal
#include "hal_afe.h"
#include "hal_wdt.h"
#include "hal_pmu.h"
#include "hal_timer.h"
#include "hal_uart.h"

//debug
#include "framework_sample.h"
#include "framework_debug.h"

//config
#include "hal_config.h"

uint16_t g_afe_channel[CH_NUM] = AFE_CHANNEL_CONFIG;
uint8_t g_ainn_channel[CH_NUM] = CHANNEL_N_CONFIG;
uint8_t g_ainp_channel[CH_NUM] = CHANNEL_P_CONFIG;

#define ABS(x)  (((x)>0) ? (x) : (0-(x)))
#define BIT(X) ((uint32_t)(1)<<(X))

#define DAC_PHY2LOGIC(x)    ((x)>2048?(~((x) &(2048-1))+1):(x))
#define DAC_LOGIC2PHY(x)    ((x)<0?(2048-(x)):(x))

volatile uint8_t AFE0_Finish = 0;

static int16_t s_adc_accumulate[CH_MAX] = {0};

uint16_t DACOffset[CH_NUM] = {0x00};
uint16_t ADCOffset[CH_NUM] = {0x00};

int16_t hal_afe_rawdata[CH_NUM];

static uint8_t hal_afe_flag_adc_overflow = 0;

static void hal_afe_wait_sample_finished(uint8_t afe_num);
static void hal_afe_set_dac_ch(uint8_t AFE_Channelx, uint16_t val);
static void hal_afe_calibration_all(void);
static int16_t hal_afe_data_get(uint8_t afe_num, uint8_t ChannelIdx);

/**
* @fn static void hal_afe_calibration_all(void)
* @brief calibration all ch
* @param None
* @return None
*/
static void hal_afe_calibration_all(void)       // DAC У������ͨ��
{
    uint8_t ch;

    for(ch = 0; ch < CH_NUM; ch++)
    {
        hal_afe_calibration_ch(g_afe_channel, ch);
    }
}

/**
* @fn static void hal_afe_calibration_ch(uint8_t afe_num, uint8_t ChannelIdx)
* @brief calibration one ch
* @param [in]afe_num:AFE num, [in]ChannelIdx: ch num, [in]first_flag: 1:first time
* @return None
*/
void hal_afe_calibration_ch(uint16_t *afe_channel_t, uint8_t ChannelIdx)     // DACУ����ͨ��
{
    uint16_t ADC_Val = 0x00;
    uint16_t dac_logic = 0;
    uint8_t iteration_cnt;
    uint32_t pre_cfg = AFE->ADCHER;                                     //����֮ǰ��ͨ������

    afe2_adc_channel_enable_ctrl(AFE2_AIN_Channel_0,DISABLE);           //��ʱ�ر���������У׼��ͨ��
    afe2_adc_channel_enable_ctrl(AFE2_AIN_Channel_1,DISABLE);
    afe2_adc_channel_enable_ctrl(AFE2_AIN_Channel_2,DISABLE);
    afe2_adc_channel_enable_ctrl(AFE2_AIN_Channel_3,DISABLE);
    afe2_adc_channel_enable_ctrl(AFE2_AIN_Channel_4,DISABLE);
    afe2_adc_channel_enable_ctrl(AFE2_AIN_Channel_5,DISABLE);
    afe2_adc_channel_enable_ctrl(AFE2_AIN_Channel_6,DISABLE);
    afe2_adc_channel_enable_ctrl(AFE2_AIN_Channel_7,DISABLE);
    afe2_adc_channel_enable_ctrl(AFE2_AIN_Channel_8,DISABLE);
    afe2_adc_channel_enable_ctrl(AFE2_AIN_Channel_9,DISABLE);
    afe2_adc_channel_enable_ctrl(g_afe_channel[ChannelIdx],ENABLE);         //ʹ����ҪУ׼��ͨ��
    hal_timer_delay_us(10);

    afe2_dac_data_set(afe_channel_t[ChannelIdx], 0);                        //��ʼ��DACֵΪ0
    afe2_dac_channel_enable_ctrl(afe_channel_t[ChannelIdx],ENABLE);          //DAC_ENn(ͨ��n DACʹ��)

    afe2_adc_conversion_start();//��ʼADCת��
    while(afe2_adc_result_valid_flag_get(afe_channel_t[ChannelIdx])==RESET); //�ȴ�ת�����
    ADC_Val = afe2_adc_conversion_value_get(afe_channel_t[ChannelIdx]);      //��ȡ��ֵ
    if((ADC_Val & BIT(15)) == 0)                                             //�ж�ʧ����ѹ����
    {
        dac_logic |= BIT(11);
    }
    dac_logic |= BIT(10);
    afe2_dac_data_set(afe_channel_t[ChannelIdx], dac_logic);
    afe2_dac_channel_enable_ctrl(afe_channel_t[ChannelIdx],ENABLE);         //DAC_ENn(ͨ��n DACʹ��)
    for(iteration_cnt = 10; iteration_cnt > 0; iteration_cnt--)             //���ַ�ȷ��DACֵ
    {
        afe2_adc_conversion_start();//��ʼADCת��
        while(afe2_adc_result_valid_flag_get(afe_channel_t[ChannelIdx])==RESET); //�ȴ�ת�����
        ADC_Val = afe2_adc_conversion_value_get(afe_channel_t[ChannelIdx]); //��ȡ��ֵ
        if((ADC_Val >> 15) == (dac_logic >> 11))
        {
            dac_logic &= ~BIT(iteration_cnt);
        }
        dac_logic |= BIT(iteration_cnt - 1);
        afe2_dac_data_set(afe_channel_t[ChannelIdx], dac_logic);
        afe2_dac_channel_enable_ctrl(afe_channel_t[ChannelIdx],ENABLE);     //DAC_ENn(ͨ��n DACʹ��)
    }
    DACOffset[ChannelIdx] = DAC_PHY2LOGIC(dac_logic);
    ADCOffset[ChannelIdx] = ADC_Val;
    afe2_adc_channel_enable_ctrl(afe_channel_t[ChannelIdx],DISABLE);        // �ر�У׼ͨ��
    afe2_adc_channel_enable_ctrl(pre_cfg,ENABLE);                           // ��ԭԭͨ�������趨
}

/**
* @fn static void hal_afe_wait_sample_finished(uint8_t afe_num)
* @brief wait afe sample finish
* @param [in]afe_num:AFE num
* @return None
*/
static void hal_afe_wait_sample_finished(uint8_t afe_num)       // �ȴ�AFE�������
{
#if HAL_AFE_INT_ENBALE
    do{      
        if(i2c_flag_status_get(I2C_STS_BUSYF) == RESET)
    {
            hal_pmu_enter_deep_sleep1();
        }
    }
    while(AFE0_Finish == 0);
    AFE0_Finish = 0;
#else
    while(afe_adc_conver_status_get(ADC_CONVER_CTRL) == 0);
#endif

}

/**
* @fn static int16_t hal_afe_data_get(uint8_t afe_num, uint8_t ChannelIdx)
* @brief get afe sample data
* @param [in]afe_num:AFE num, [in]ChannelIdx: ch num
* @return None
*/
static int16_t hal_afe_data_get(uint8_t afe_num, uint8_t ChannelIdx)    // ��ȡAFE��������
{
    uint16_t temp;
    int16_t val = 0;
    uint8_t chn = g_afe_channel[ChannelIdx];

    temp = afe2_adc_conversion_value_get(chn);

    val = temp>>2;

    return val;
}

/**
* @fn static void hal_afe_enable(uint8_t afe_num)
* @brief AFE enable
* @param [in]afe_num:AFE num
* @return None.
*/
static void hal_afe_enable(uint8_t afe_num)             // AFE ��ع���ʹ�ܣ�����PGA,DAC,VS
{
    afe2_pga_enable_ctrl(ENABLE);//open PGA
    afe2_adc_enable_ctrl(ENABLE);//open ADC
    //afe2_dac_enable_ctrl(ENABLE);//open DAC
    afe2_vs_enable_ctrl(ENABLE);//open  VS
}
/**
* @fn static void hal_afe_disable(uint8_t afe_num)
* @brief AFE disable
* @param [in]afe_num:AFE num
* @return None.
*/
static void hal_afe_disable(uint8_t afe_num)            // AFE ��ع��ܹرգ�����PGA,DAC,VS
{
    afe2_pga_enable_ctrl(DISABLE);//close PGA
    afe2_adc_enable_ctrl(DISABLE);//close ADC
    afe2_dac_enable_ctrl(DISABLE);//close DAC
    afe2_vs_enable_ctrl(DISABLE);//close  VS
}

/**
* @fn static void hal_afe_set_dac_ch(uint8_t AFE_Channelx, uint16_t val)
* @brief set DAC value
* @param [in]afe_num:AFE num, [in]AFE_Channelx: ch num, [in]val: data
* @return None.
*/
static void hal_afe_set_dac_ch(uint8_t AFE_Channelx, uint16_t val)     // ����ͨ��DAC �Ĵ���ֵ
{
    afe2_dac_data_set(AFE_Channelx,val);
}

/**
* @fn static void hal_afe_sample_chx(uint8_t afe_num, uint8_t channelIdx)
* @brief sample ch
* @param [in]afe_num:AFE num, [in]channelIdx: ch num
* @return None.
*/
static void hal_afe_sample_chx(uint8_t afe_num, uint8_t channelIdx)         // ʹ��ͨ���������ȴ����
{
    afe2_adc_channel_enable_ctrl(g_afe_channel[channelIdx],ENABLE);         // ���ò���ͨ��
    afe2_adc_conversion_start();                                            // ��������
    hal_afe_wait_sample_finished(afe_num);                                  // �ȴ��������
    afe2_adc_channel_enable_ctrl(g_afe_channel[channelIdx],DISABLE);        // �رղ���ͨ��
}

/**
* @fn uint8_t hal_afe_info_get(uint8_t *info_data)
* @brief get age sample info
* @param [in]info_data: point to data
* @return data num
*/
uint8_t hal_afe_info_get(uint8_t *info_data)                                // ��ȡAFE��Ϣ���ݣ�����PGA,DAC offset��ADC offset
{
    char i;

    info_data[0] = HAL_AFE_PGA1_GAIN;
    info_data[1] = HAL_AFE_PGA2_GAIN;
    /* CH_NUM���ݱ������offset�����ˣ�����ʹ�� */
    /* ͨ�����Ի�ȡ��̬�����е�ͨ����Ϊ׼ */
    info_data[2] = CH_NUM;

    for(i = 0; i < CH_NUM; i++)
    {
        info_data[4 * i + 2] = (uint8_t)DACOffset[i];
        info_data[4 * i + 3] = (uint8_t)(DACOffset[i] >> 8);
        info_data[4 * i + 4] = (uint8_t) ADCOffset[i];
        info_data[4 * i + 5] = (uint8_t)(ADCOffset[i] >> 8);
    }

    return (CH_NUM * 4 + 2);
}

/**
* @fn void hal_afe_interrput(void)
* @brief afe interrupt fun
* @param None
* @return None.
*/
void hal_afe_interrput(void)                // AFE �����жϵ��ú���
{
    afe2_interrupt_flag_clear();
    AFE0_Finish = 1;
}

/**
* @fn hal_afe_ch_num_get(void)
* @brief get ch num
* @param None
* @return ch num
*/
uint8_t hal_afe_ch_num_get(void)            // ��ȡ����ͨ����
{
    return CH_NUM;
}
/**
* @fn void afe_adc_calibration(void)
* @brief afe adc calibration
* @param None
* @return None
*/
static uint8_t afe_adc_calibration(void)
{
//afe2_vs_voltage_set(HAL_AFE_VS);						//VS level  28.V
    afe2_adc_enable_ctrl(ENABLE);                       //open ADC
    afe2_vs_enable_ctrl(ENABLE);                        //open VS

    //Enable ADC
    afe2_adc_calibration_start();
    while(afe2_flag_status_get(AFE2_FLAG_CALF) == 0);   //wait for calibration finish
    afe2_flag_clear(AFE2_FLAG_CALF);                    //���У׼��ɱ�־λ
    return afe2_flag_status_get(AFE2_FLAG_CAL_VALID);
}

/**
* @fn void hal_afe_sample_param_init(void)
* @brief init sample param
* @param None
* @return None
*/
static void hal_afe_sample_param_init()
{
    uint8_t i;

    afe2_config_t p_afe_config;
    for(i = 0; i < CH_NUM; i++)                                  // ������ͨ������
    {
        afe2_adc_channel_config(g_afe_channel[i], g_ainp_channel[i], g_ainn_channel[i]);
    }
    p_afe_config.data_format = 0;
    p_afe_config.sample_time = AFE2_SAMPLE_TIME_8Cycles;
    p_afe_config.average_num = AFE2_AVERAGE_NUM_16;	             //16����Чת������
    p_afe_config.stop_mode = 0;
    p_afe_config.setup_time_int = AFE2_SETUP_TIME_240Cycles;    //20us����ʱ��
    p_afe_config.average_mode = AFE2_AVERAGE_MODE_TRIM;
    p_afe_config.conv_mode = AFE2_CONV_MODE_SINGLE_SCAN;//AFE2_CONV_MODE_LIMITED_SCAN;  //��������ɨ��
    p_afe_config.power_mode = AFE2_POWER_MODE_LP;
    afe2_init(&p_afe_config);

    for(i = 0; i < CH_NUM; i++)                                  // ������ͨ������
    {
        afe2_pga_gain_set(g_afe_channel[i],HAL_AFE_PGA1_GAIN,HAL_AFE_PGA2_GAIN);
    }
    afe2_pga_enable_ctrl(ENABLE);
}
/**
* @fn void hal_afe_init(void)
* @brief afe init
* @param None
* @return ch num
*/
void hal_afe_init(void)                                         // AFEģ���ʼ��������ͨ��DACУ��
{
    static uint8_t valid;
    gpio_config_t gpio_config;
    nvic_config_t ptr_config;
    uint32_t i;

    for(i = 0; i < CH_NUM; i++)
    {
        gpio_mf_config(GPIO_GROUP_A, GPIO_PIN_NUM0,GPIO_MUX_FUNC_1);            //VS0
        // ����ͨ����IO����
        if((g_ainn_channel[i] == AFE2_AINN_SOURCE_FT10) || (g_ainp_channel[i] == AFE2_AINP_SOURCE_FT10 )){
            
            gpio_mf_config(GPIO_GROUP_B, GPIO_PIN_NUM4, GPIO_MUX_FUNC_3);
            gpio_mf_config(GPIO_GROUP_B, GPIO_PIN_NUM5, GPIO_MUX_FUNC_5);            
            gpio_config.mode = GPIO_MODE_AN;
            gpio_config.pin = GPIO_PIN_4;
            gpio_config.pull = GPIO_PULL_NO_PULL;
            gpio_init(GPIO_GROUP_B,&gpio_config);
        }
        if((g_ainn_channel[i] == AFE2_AINN_SOURCE_FT11) || (g_ainp_channel[i] == AFE2_AINP_SOURCE_FT11 )){
            gpio_mf_config(GPIO_GROUP_B, GPIO_PIN_NUM5, GPIO_MUX_FUNC_5);
            gpio_config.mode = GPIO_MODE_AN;
            gpio_config.pin = GPIO_PIN_5;
            gpio_config.pull = GPIO_PULL_NO_PULL;
            gpio_init(GPIO_GROUP_B,&gpio_config);            
        }
    }
    syscfg_regwrprot_disable();
    rcc_hirc_adc_enable_ctrl(ENABLE);                                           // ʹ���ڲ� 24Mhz ��������
    syscfg_regwrprot_enable();
    rcc_apb_periph_clock_enable_ctrl(RCC_APBPeriph_AFE2, ENABLE);               // AFE ADC ʱ��ʹ�ܿ���

    afe2_vs_voltage_set(HAL_AFE_VS);                                            //VS level  28.V
    hal_afe_sample_param_init();    
    afe2_vs_limit_enable_ctrl(ENABLE);
//  afe2_vs_output_enable_ctrl(ENABLE);             // VS_SEL(��Ӳ������VS0���������ر�,ֻ��ת��FTͨ��ʱ����)
    afe2_vs_enable_ctrl(ENABLE);                    // VS_EN
    hal_timer_delay_ms(6);
    afe2_vs_limit_enable_ctrl(DISABLE);
    hal_timer_delay_ms(1);
    do
    {
        valid = afe_adc_calibration();				// adc calibration
    }while(valid == 0);
#if HAL_AFE_INT_ENBALE                                                          // ѡ���Ƿ�ʹ��AFE��������ж�  
    ptr_config.nvic_channel_priority = 1;
    ptr_config.nvic_enable_flag = ENABLE;
    ptr_config.nvic_IRQ_channel = IRQn_AFE2;
    nvic_init(&ptr_config);
    afe2_adc_interrupt_enable_ctrl(ENABLE);
#else
    afe_adc_interrupt_disable();
#endif       
    for(i = 0; i < CH_NUM; i++){                    // ������ͨ������
        afe2_pga_bypass_set(g_afe_channel[i],AFE2_PGA_BYPASS_NONE);   // default config AA bypass
    }											   
    //--dac---------------------------------------------
    afe2_dac_vref_set(AFE2_DAC_VREF_2VS);           //DAC ��� (NP) rang = 800mV

    afe2_pga_enable_ctrl(ENABLE);                   //open PGA
    afe2_vs_enable_ctrl(ENABLE);                    //open  VS
    afe2_adc_enable_ctrl(ENABLE);                   //open ADC
    //afe2_dac_enable_ctrl(ENABLE);
    hal_afe_calibration_all();                      //DACУ��ʹ�ܵ�ͨ��
    afe2_vs_enable_ctrl(DISABLE);
}

/**
* @fn int16_t hal_afe_get_rawdata(int ch)
* @brief get afe sample data
* @param [in]ch: ch num
* @return sample data
*/
extern int16_t calibrate_offset[];
int16_t hal_afe_get_rawdata(int ch)                 //��ȡָ����ͨ������ֵ
{
    if(ch < CH_NUM)
    {
        return hal_afe_rawdata[ch] - BASE_LINE + calibrate_offset[TK_CH_NUM+ch];
    }
    return 0;
}

/**
* @fn uint8_t hal_afe_get_adc_overflow(void)
* @brief
* @param
* @return
*/
uint8_t hal_afe_get_adc_overflow(void)                             // ��ȡADC�ۼ��Ƿ�������
{
    return hal_afe_flag_adc_overflow;
}

/**
* @fn void hal_afe_sample(void)
* @brief sample proc
* @param None
* @return None.
*/
uint16_t hal_afe_temperature_sample(uint8_t ChannelIdx)         // �����¶Ȳ���
{
    uint16_t adc_value;

    hal_afe_enable(HAL_AFE_NUM);                                //  ����AFE����
    afe2_adc_channel_enable_ctrl(ChannelIdx,ENABLE);            // ���ò���ͨ��
    hal_timer_delay_us(10);    
    afe2_adc_conversion_start();                                // ��������
    hal_afe_wait_sample_finished(0);                            // �ȴ��������
    afe2_adc_channel_enable_ctrl(ChannelIdx,DISABLE);           // �رղ���ͨ��
    adc_value = afe2_adc_conversion_value_get(ChannelIdx);
    adc_value = (adc_value>>2);
    hal_afe_disable(HAL_AFE_NUM);                               //  �ر�AFE����
    return adc_value;
}


/**
* @fn void hal_afe_sample(void)
* @brief sample proc
* @param None
* @return None.
*/
void hal_afe_sample(void)                                       // ����AFE����
{
    char i;
    int16_t adc_value;

    hal_afe_flag_adc_overflow = 0;
    hal_afe_enable(HAL_AFE_NUM);                                // ����AFE����
    for(i = 0; i < CH_NUM; i++)                                 // ���β���ʹ�ܵ�ͨ��
    {
        hal_afe_sample_chx(HAL_AFE_NUM, i);
        adc_value = hal_afe_data_get(HAL_AFE_NUM, i);
        hal_afe_rawdata[i] = adc_value + s_adc_accumulate[i];   // ���������ۼ��������Ĳ���ֵ
    }
    hal_afe_disable(HAL_AFE_NUM);                               // �ر�AFE����
}

int16_t get_adc_accumulate_data(uint8_t ch)
{
    return s_adc_accumulate[ch];    
}
/**
* @fn uint8_t get_comparing_values(int16_t value)
* @brief ger adc value comparing status
* @param [in]adc value: ch num
* @return status
*/
static uint8_t hal_get_comparing_values(int16_t value)
{
    uint8_t status;

    if(value < 0x0800)
    {
        status = 1;      //    (-VS)---(-0.25VS)
    }
    else if(value > 0x07FF && value < 0x1800)
    {
        status = 2;      //    (-0.25VS)---(-0.75VS)
    }
    else if(value > 0x17FF && value < 0x2800)
    {
        status = 3;      //    (-0.75VS)---(+0.25VS)
    }
    else if(value > 0x27FF && value < 0x3800)
    {
        status = 4;      //    (+0.25VS)---(+0.75VS)
    }
    else if(value > 0x37FF && value < 0x4001)
    {
        status = 5;      //    (+0.75VS)---(+VS)
    }
    else
    {
        status = 6;      //    other situation
    }
    return status;
}
/**
* @fn uint16_t hal_get_sensor_state( uint8_t ChannelIdx)
* @brief None
* @param None
* @return None.
*/
uint16_t hal_get_sensor_state( uint8_t ChannelIdx)
{
    uint8_t i;
    uint16_t sensor_status = 0;
    uint8_t subType[6] = {0};
    int16_t adc_value[6] = {0};

    afe2_pga_bypass_set(g_afe_channel[ChannelIdx],AFE2_PGA_BYPASS_BOTH);
    afe2_adc_channel_config(g_afe_channel[ChannelIdx], g_ainn_channel[ChannelIdx],AFE2_AINP_SOURCE_HALF_VS);//���� P�� ��VS/2
    //  ����P����
    hal_afe_enable(HAL_AFE_NUM);                                    // ����AFE����
    afe2_pull_up_enable_ctrl(ENABLE);
    afe2_pull_down_enable_ctrl(DISABLE);
    hal_timer_delay_ms(5);
    hal_afe_sample_chx(HAL_AFE_NUM, ChannelIdx);
    adc_value[0] = hal_afe_data_get(HAL_AFE_NUM, ChannelIdx);

    afe2_pull_up_enable_ctrl(DISABLE);
    afe2_pull_down_enable_ctrl(ENABLE);
    hal_timer_delay_ms(5);
    hal_afe_sample_chx(HAL_AFE_NUM, ChannelIdx);
    adc_value[1] = hal_afe_data_get(HAL_AFE_NUM, ChannelIdx);

    afe2_pull_up_enable_ctrl(DISABLE);
    afe2_pull_down_enable_ctrl(DISABLE);
    hal_timer_delay_ms(5);
    hal_afe_sample_chx(HAL_AFE_NUM, ChannelIdx);
    adc_value[2] = hal_afe_data_get(HAL_AFE_NUM, ChannelIdx);

    // ����N����
    afe2_adc_channel_config(g_afe_channel[ChannelIdx], g_ainp_channel[ChannelIdx], AFE2_AINP_SOURCE_HALF_VS); //���� N�� ��VS/2

    afe2_pull_up_enable_ctrl(ENABLE);
    afe2_pull_down_enable_ctrl(DISABLE);
    hal_timer_delay_ms(5);
    hal_afe_sample_chx(HAL_AFE_NUM, ChannelIdx);
    adc_value[3] = hal_afe_data_get(HAL_AFE_NUM, ChannelIdx);

    afe2_pull_up_enable_ctrl(DISABLE);
    afe2_pull_down_enable_ctrl(ENABLE);
    hal_timer_delay_ms(5);
    hal_afe_sample_chx(HAL_AFE_NUM, ChannelIdx);
    adc_value[4] = hal_afe_data_get(HAL_AFE_NUM, ChannelIdx);

    afe2_pull_up_enable_ctrl(DISABLE);
    afe2_pull_down_enable_ctrl(DISABLE);
    hal_timer_delay_ms(5);
    hal_afe_sample_chx(HAL_AFE_NUM, ChannelIdx);
    adc_value[5] = hal_afe_data_get(HAL_AFE_NUM, ChannelIdx);

    hal_afe_disable(HAL_AFE_NUM);                                    // �ر�AFE����

    // �ָ�AFE����
    afe2_pull_up_enable_ctrl(DISABLE);
    afe2_pull_down_enable_ctrl(DISABLE);
    afe2_pga_bypass_set(g_afe_channel[ChannelIdx],AFE2_PGA_BYPASS_NONE);
    hal_afe_sample_param_init();

    for(i = 0; i < 6; i++)
    {
        subType[i] = hal_get_comparing_values(adc_value[i]);
    }

    if((subType[0] == 4) && (subType[1] == 2))
    {
        sensor_status = 0x01;       //R1-OPEN      R2-OPEN
    }
    else if((subType[0] == 2) && (subType[1] == 2)  && (subType[2] == 2))
    {
        sensor_status = 0x02;       //R1-OPEN/NORMAL/SHORT    R2-SHORT
    }
    else if((subType[0] == 3) && (subType[1] == 2)  && (subType[2] == 2))
    {
        sensor_status = 0x03;       //R1-OPEN      R2-NORMAL
    }
    else if((subType[0] == 4) && (subType[1] == 3)  && (subType[2] == 4))
    {
        sensor_status = 0x04;       //R1-NORMAL    R2-OPEN
    }
    else if((subType[0] == 3) && (subType[1] == 3)  && (subType[2] == 3))
    {
        sensor_status = 0x05;       //R1-NORMAL    R2-NORMAL
    }
    else if((subType[0] == 4) && (subType[1] == 4)  && (subType[2] == 4))
    {
        sensor_status = 0x06;       //R1-SHORT     R2-NORMAL/OPEN
    }
    else
    {
        sensor_status = 0x07;       //    other situation
    }

    if((subType[3] == 4) && (subType[4] == 2))
    {
        sensor_status |= 0x10;      //R3-OPEN      R4-OPEN
    }
    else if((subType[3] == 2) && (subType[4] == 2)  && (subType[5] == 2))
    {
        sensor_status |= 0x20;      //R3-OPEN/NORMAL/SHORT    R4-SHORT
    }
    else if((subType[3] == 3) && (subType[4] == 2)  && (subType[5] == 2))
    {
        sensor_status |= 0x30;      //R3-OPEN      R4-NORMAL
    }
    else if((subType[3] == 4) && (subType[4] == 3)  && (subType[5] == 4))
    {
        sensor_status |= 0x40;      //R3-NORMAL    R4-OPEN
    }
    else if((subType[3] == 3) && (subType[4] == 3)  && (subType[5] == 3))
    {
        sensor_status |= 0x50;      //R3-NORMAL    R4-NORMAL
    }
    else if((subType[3] == 4) && (subType[4] == 4)  && (subType[5] == 4))
    {
        sensor_status |= 0x60;      //R3-SHORT     R4-NORMAL/OPEN
    }
    else
    {
        sensor_status |= 0x70;      //    other situation
    }
    return sensor_status;
}
/**
  * @}
  */

/**
  * @}
  */

/************************ (C) COPYRIGHT Chipsea Tech *****END OF FILE****/
