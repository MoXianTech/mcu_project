.\objects\startup_csa37f72.o: RTE\Device\CSA37F72\startup_csa37f72.S
