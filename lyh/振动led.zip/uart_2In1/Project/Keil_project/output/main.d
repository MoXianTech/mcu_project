./output/main.o: ..\main.c \
  E:\Keil_32\ARM\ARMCLANG\Bin\..\include\stdlib.h \
  ..\..\Firmware\CMSIS\GD\GD32E10x\Include\gd32e10x.h \
  ..\..\Firmware\CMSIS\core_cm4.h \
  E:\Keil_32\ARM\ARMCLANG\Bin\..\include\stdint.h \
  ..\..\Firmware\CMSIS\core_cmInstr.h ..\..\Firmware\CMSIS\core_cmFunc.h \
  ..\..\Firmware\CMSIS\core_cm4_simd.h \
  ..\..\Firmware\CMSIS\GD\GD32E10x\Include\system_gd32e10x.h \
  ..\gd32e10x_libopt.h \
  ..\..\Firmware\GD32E10x_standard_peripheral\Include\gd32e10x_rcu.h \
  ..\..\Firmware\GD32E10x_standard_peripheral\Include\gd32e10x_adc.h \
  ..\..\Firmware\GD32E10x_standard_peripheral\Include\gd32e10x_can.h \
  ..\..\Firmware\GD32E10x_standard_peripheral\Include\gd32e10x_crc.h \
  ..\..\Firmware\GD32E10x_standard_peripheral\Include\gd32e10x_ctc.h \
  ..\..\Firmware\GD32E10x_standard_peripheral\Include\gd32e10x_dac.h \
  ..\..\Firmware\GD32E10x_standard_peripheral\Include\gd32e10x_dbg.h \
  ..\..\Firmware\GD32E10x_standard_peripheral\Include\gd32e10x_dma.h \
  ..\..\Firmware\GD32E10x_standard_peripheral\Include\gd32e10x_exti.h \
  ..\..\Firmware\GD32E10x_standard_peripheral\Include\gd32e10x_fmc.h \
  ..\..\Firmware\GD32E10x_standard_peripheral\Include\gd32e10x_fwdgt.h \
  ..\..\Firmware\GD32E10x_standard_peripheral\Include\gd32e10x_gpio.h \
  ..\..\Firmware\GD32E10x_standard_peripheral\Include\gd32e10x_i2c.h \
  ..\..\Firmware\GD32E10x_standard_peripheral\Include\gd32e10x_pmu.h \
  ..\..\Firmware\GD32E10x_standard_peripheral\Include\gd32e10x_bkp.h \
  ..\..\Firmware\GD32E10x_standard_peripheral\Include\gd32e10x_rtc.h \
  ..\..\Firmware\GD32E10x_standard_peripheral\Include\gd32e10x_spi.h \
  ..\..\Firmware\GD32E10x_standard_peripheral\Include\gd32e10x_timer.h \
  ..\..\Firmware\GD32E10x_standard_peripheral\Include\gd32e10x_usart.h \
  ..\..\Firmware\GD32E10x_standard_peripheral\Include\gd32e10x_wwdgt.h \
  ..\..\Firmware\GD32E10x_standard_peripheral\Include\gd32e10x_misc.h \
  ..\..\Firmware\GD32E10x_standard_peripheral\Include\gd32e10x_exmc.h \
  ..\systick.h E:\Keil_32\ARM\ARMCLANG\Bin\..\include\stdio.h \
  ..\Keil_project\ws2812.h ..\main.h ..\..\Bsp\uart.h \
  E:\Keil_32\ARM\ARMCLANG\Bin\..\include\string.h ..\systick.h \
  E:\Keil_32\ARM\ARMCLANG\Bin\..\include\stdbool.h ..\..\Bsp\timer.h \
  ..\..\Bsp\adc.h ..\..\Bsp\MRT\mx_serial_core.h ..\main.h \
  ..\..\Bsp\74HC4051BQ.h ..\..\Bsp\pressure.h ..\..\Bsp\resis.h \
  ..\..\Bsp\malloc\priv_malloc.h ..\..\Bsp\pwm\pwm.h \
  ..\..\Bsp\vofa\vofa.h ..\..\Bsp\differential\differential_math.h \
  ..\..\Bsp\gt9147\gt9147.h ..\..\Bsp\Soft_i2c\soft_i2c.h \
  ..\..\Bsp\HX_driver\cs_press_driver.h
