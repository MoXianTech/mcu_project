./output/circular_buffer.o: circular_buffer.c \
  ..\Keil_project\circular_buffer.h \
  E:\Keil_32\ARM\ARMCLANG\Bin\..\include\stdlib.h \
  E:\Keil_32\ARM\ARMCLANG\Bin\..\include\string.h \
  E:\Keil_32\ARM\ARMCLANG\Bin\..\include\limits.h
