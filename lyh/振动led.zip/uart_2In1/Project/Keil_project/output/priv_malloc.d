./output/priv_malloc.o: ..\..\Bsp\malloc\priv_malloc.c \
  ..\..\Bsp\malloc\priv_malloc.h \
  E:\Keil_32\ARM\ARMCLANG\Bin\..\include\stdint.h
