#ifndef _IO_H_
#define _IO_H_

#include "gd32e10x.h"

void io_init(void);
void ledG_on(void);
void ledG_off(void);
void ledG_not(void);



#endif
