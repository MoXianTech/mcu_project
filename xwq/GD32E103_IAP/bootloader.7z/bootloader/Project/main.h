
#ifndef __MAIN_H
#define __MAIN_H



#define RAM_MAP_ID_START        0
#define RAM_MAP_ID_LENGTH       5

#define RAM_MAP_MSG_START       5
#define RAM_MAP_MSG_LENGTH      1



#define TX_RX_TIME         20
#define TX_RX_TIME_HALF    10
#define TX_RX_TIME_ERROR   2

#define TX_TIME_WAIT       2


#endif


