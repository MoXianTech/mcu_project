.\output\resi_math_lib.o: ..\..\Lib\resi_math_lib.c
.\output\resi_math_lib.o: ..\..\Lib\resi_math_lib.h
.\output\resi_math_lib.o: C:\Keil_v5\ARM\ARMCC\Bin\..\include\stdint.h
