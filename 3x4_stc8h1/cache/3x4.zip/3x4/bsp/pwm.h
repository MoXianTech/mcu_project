#ifndef __PWM_H
#define __PWM_H
#define SYSCLK 24000000L



#endif